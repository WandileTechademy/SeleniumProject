# SeleniumProject
Group Members 
 <li>1 Gowri Shankar G</li>
<li>2 Jesse</li>
<li>3 Girish</li>
<li>4 Shilo</li>
<li>5 Nithin</li>
<li>6 Wandile</li>

## LoginTest
For login Test I have failed all the test cases since they would be used later during cart addition
